import asyncio
from callsmusic.callsmusic import client as USER
from config import BOT_USERNAME, SUDO_USERS
from helpers.decorators import authorized_users_only, sudo_users_only, errors
from helpers.filters import command
from pyrogram import Client, filters
from pyrogram.errors import UserAlreadyParticipant


@Client.on_message(
    command(["join", f"join@{BOT_USERNAME}"]) & ~filters.private & ~filters.bot
)
@authorized_users_only
@errors
async def join_group(client, message):
    chid = message.chat.id
    try:
        invitelink = await client.export_chat_invite_link(chid)
    except:
        await message.reply_text(
            "• **من پرمیشن زیر رو ندارم:**\n\n» ❌ __Add Users__",
        )
        return

    try:
        user = await USER.get_me()
    except:
        user.first_name = "music assistant"

    try:
        await USER.join_chat(invitelink)
    except UserAlreadyParticipant:
        pass
    except Exception as e:
        print(e)
        await message.reply_text(
            f"🛑 ارور 🛑 \n\n**دقایقی صبر کنید یا خودتان پلیر را به گروه اد کنید**"
        )
        return
    await message.reply_text(
        f"✅ **پلیر اضافه شد**",
    )


@Client.on_message(
    command(["leave", f"leave@{BOT_USERNAME}"]) & filters.group & ~filters.edited
)
@authorized_users_only
async def leave_group(client, message):
    try:
        await USER.send_message(message.chat.id, "✅ پلیر خارج شد")
        await USER.leave_chat(message.chat.id)
    except:
        await message.reply_text(
            "❌ **پلیر نمیتواند از گروه خارج شود.**\n\n**» دقایقی صبر کنید یا شخصا آن را حذف کنید**"
        )

        return
