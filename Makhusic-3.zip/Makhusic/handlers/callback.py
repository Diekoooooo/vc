from pyrogram import Client, filters
from pyrogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup
from config import (
    ASSISTANT_NAME,
    BOT_NAME,
    BOT_USERNAME,
    GROUP_SUPPORT,
    OWNER_NAME,
    UPDATES_CHANNEL,
)


@Client.on_callback_query(filters.regex("cbstart"))
async def cbstart(_, query: CallbackQuery):
    await query.edit_message_text(
        f"""✨ **دلام [{query.message.chat.first_name}](tg://user?id={query.message.chat.id}) !**\n
💭 **[{BOT_NAME}](https://t.me/{BOT_USERNAME}) بهت این قابلیت رو میده که توی وویس چت گروه و کانالت آهنگ پخش کنی!**

💡 **اگه میخوای بدونی دستورای ربات چیان دکمه 📚 دستورات رو چک کن :)**

🔖 **اگه میخوای بدونی چطوری باید از این استفاده کنی دکمه ❓ راهنمای اولیه رو چک کن :)**""",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "➕ اضافه کردن به گروه ➕",
                        url=f"https://t.me/{BOT_USERNAME}?startgroup=true",
                    )
                ],
                [InlineKeyboardButton("❓ راهنمای اولیه", callback_data="cbhowtouse")],
                [
                    InlineKeyboardButton("📚 دستورات", callback_data="cbcmds"),
                    InlineKeyboardButton("❤️", url=f"https://t.me/{OWNER_NAME}"),
                ],
                [
                    InlineKeyboardButton(
                        "👥 گروه", url=f"https://t.me/{GROUP_SUPPORT}"
                    ),
                    InlineKeyboardButton(
                        "📣 کانال", url=f"https://t.me/{UPDATES_CHANNEL}"
                    ),
                ],
            ]
        ),
        disable_web_page_preview=True,
    )


@Client.on_callback_query(filters.regex("cbhelp"))
async def cbhelp(_, query: CallbackQuery):
    await query.edit_message_text(
        f"""✨ **دلام !**

» **دکمه های زیر برای دیدن کامند هاست !**

""",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton("📚 دستورات اولیه", callback_data="cbbasic"),
                    InlineKeyboardButton("📕 دستورات پیشرفته", callback_data="cbadvanced"),
                ],
                [
                    InlineKeyboardButton("📘 دستورات ادمین", callback_data="cbadmin"),
                ],
                [InlineKeyboardButton("🔙 برگشت", callback_data="cbguide")],
            ]
        ),
    )


@Client.on_callback_query(filters.regex("cbbasic"))
async def cbbasic(_, query: CallbackQuery):
    await query.edit_message_text(
        f"""🏮 **اینها دستوران ابتدایی هستند**

🎧 [ VOICE CHAT PLAY CMD ]

/play (نام آهنگ) - پخش آهنگ از یوتیوب
/stream (ریپلای به فایل) - پخش آهنگ با فایل
/playlist - دیدن آهنگ ها
/song (نام آهنگ) - دانلود آهنگ از یوتیوب
/search (نام ویدیو) - سرچ ویدیو در یوتیوب
/video (نام ویدیو) - دانلود ویدیو از یوتیوب
/lyric (نام آهنگ) - متن آهنگ

""",
        reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton("🔙 برگشت", callback_data="cbhelp")]]
        ),
    )


@Client.on_callback_query(filters.regex("cbadvanced"))
async def cbadvanced(_, query: CallbackQuery):
    await query.edit_message_text(
        f"""🏮 **اینها دستورات پیشرفته هستند**

/start (در گروه) - وضعیت ربات
/reload - ریلود ربات
/ping - چک کردن پینگ ربات
/uptime - چک کردن آپتایم ربات

""",
        reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton("🔙 برگشت", callback_data="cbhelp")]]
        ),
    )


@Client.on_callback_query(filters.regex("cbadmin"))
async def cbadmin(_, query: CallbackQuery):
    await query.edit_message_text(
        f"""🏮 **دستورات ادمین**

/pause - توقف آهنگ
/resume - ادامه آهنگ
/skip - رفتن به آهنگ بعدی
/end - قطع کردن
/join - اضافه کردن ربات پلیر به گروه
/leave - حذف ربات پلیر از گروه
/auth - ارائه دسترسی
/unauth - حذف دسترسی
/control - باز کردن کنترل پنل



""",
        reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton("🔙 برگشت", callback_data="cbhelp")]]
        ),
    )



@Client.on_callback_query(filters.regex("cbguide"))
async def cbguide(_, query: CallbackQuery):
    await query.edit_message_text(
        f"""❓ **آموزش استفاده:**

1.) **ربات را به گروه اضافه کنید.**
2.) **ربات را ادمین و همه قابلیت ها را بجز قابلیت ناشناس اعطا کنید.**
3.) **سپس دستور /reload را ارسال کنید.**
3.) **با دستور /join ربات پلیر را اضافه کنید.**
4.) **وویس چت را روشن کنید.**



""",
        reply_markup=InlineKeyboardMarkup(
            [
                [InlineKeyboardButton("📚 لیست دستورات", callback_data="cbhelp")],
                [InlineKeyboardButton("🗑 بستن", callback_data="close")],
            ]
        ),
    )


@Client.on_callback_query(filters.regex("close"))
async def close(_, query: CallbackQuery):
    await query.message.delete()


@Client.on_callback_query(filters.regex("cbback"))
async def cbback(_, query: CallbackQuery):
    a = await _.get_chat_member(query.message.chat.id, query.from_user.id)
    if not a.can_manage_voice_chats:
        return await query.answer("💡 only admin can tap this button !", show_alert=True)
    await query.edit_message_text(
        "**💡 منوی کنترل ربات :**",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton("⏸ توقف", callback_data="cbpause"),
                    InlineKeyboardButton("▶️ ادامه", callback_data="cbresume"),
                ],
                [
                    InlineKeyboardButton("⏩ بعدی", callback_data="cbskip"),
                    InlineKeyboardButton("⏹ پایان", callback_data="cbend"),
                ],
                [InlineKeyboardButton("🗑 بستن", callback_data="close")],
            ]
        ),
    )



@Client.on_callback_query(filters.regex("cbcmds"))
async def cbhelps(_, query: CallbackQuery):
    await query.edit_message_text(
        f"""✨ **دلام** [{query.message.chat.first_name}](tg://user?id={query.message.chat.id}) !

» **برای دیدن همه دستورات دکمه زیر رو بزن !**

""",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton("📚 دستورات پایه", callback_data="cblocal"),
                    InlineKeyboardButton("📕 دستورات پیشرفته", callback_data="cbadven"),
                ],
                [
                    InlineKeyboardButton("📘 دستورات ادمین", callback_data="cblamp"),
                ],
                [InlineKeyboardButton("🔙 برگشت", callback_data="cbstart")],
            ]
        ),
    )


@Client.on_callback_query(filters.regex("cbhowtouse"))
async def cbguides(_, query: CallbackQuery):
    await query.edit_message_text(
        f"""❓ **آموزش استفاده:**

1.) **ربات را به گروه اضافه کنید**
2.) **ربات را ادمین و همه قابلیت ها را بجز قابلیت ناشناس اعطا کنید.**
3.) **سپس دستور /reload را ارسال کنید.**
3.) **با دستور /join ربات پلیر را اضافه کنید**
4.) **وویس چت را روشن کنید.**



""",
        reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton("🔙 برگشت", callback_data="cbstart")]]
        ),
    )


@Client.on_callback_query(filters.regex("cblocal"))
async def cblocal(_, query: CallbackQuery):
    await query.edit_message_text(
        f"""🏮 **اینها دستوران ابتدایی هستند**

🎧 [ دستورات ]

/play (نام آهنگ) - پخش آهنگ از یوتیوب
/stream (ریپلای به فایل) - پخش یک فایل
/playlist - دیدن لیست آهنگ ها
/song (نام آهنگ) - دانلود آهنگ از یوتیوب
/search (نام ویدیو) - سرچ ویدیو در یوتیوب
/video (نام ویدیو) - دانلود ویدیو
/lyric (نام آهنگ) - متن آهنگ

""",
        reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton("🔙 برگشت", callback_data="cbcmds")]]
        ),
    )


@Client.on_callback_query(filters.regex("cbadven"))
async def cbadven(_, query: CallbackQuery):
    await query.edit_message_text(
        f"""🏮 **اینها دستورات پیشرفته هستند**

/start (در گروه) - وضعیت ربات
/reload - ریلود لیست ادمین ها
/ping - چک کردن پینگ ربات
/uptime - چک کردن آپتایم ربات

""",
        reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton("🔙 برگشت", callback_data="cbcmds")]]
        ),
    )


@Client.on_callback_query(filters.regex("cblamp"))
async def cblamp(_, query: CallbackQuery):
    await query.edit_message_text(
        f"""🏮 **دستورات ادمین**

/pause - توقف آهنگ
/resume - ادامه آهنگ
/skip - رفتن به آهنگ بعدی
/end - قطع کردن
/join - اضافه کردن ربات پلیر به گروه
/leave - حذف ربات پلیر از گروه
/auth - ارائه دسترسی
/unauth - حذف دسترسی
/control - باز کردن کنترل پنل


""",
        reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton("🔙 برگشت", callback_data="cbcmds")]]
        ),
    )



@Client.on_callback_query(filters.regex("cmdhome"))
async def cmdhome(_, query: CallbackQuery):
    
    bttn = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("😕", callback_data="cmdsyntax")
            ],[
                InlineKeyboardButton("🗑 بستن", callback_data="close")
            ]
        ]
    )
    
    nofound = "😕 **یافت نشد**"
    
    await query.edit_message_text(nofound, reply_markup=bttn)


@Client.on_callback_query(filters.regex("cmdsyntax"))
async def cmdsyntax(_, query: CallbackQuery):
    await query.edit_message_text(
        f"""**دستورات ربات** برای پخش آهنگ :**

• `/play ` - برای پخش آهنگ
• `/stream ` - برای پخش فایل

⚡ __Powered by {BOT_NAME}__""",
        reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton("🔙 برگشت", callback_data="cmdhome")]]
        ),
    )
