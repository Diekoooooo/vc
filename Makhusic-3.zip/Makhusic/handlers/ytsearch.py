import json
import logging
from config import BOT_USERNAME
from helpers.filters import command
from pyrogram import Client, filters

from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)
from youtube_search import YoutubeSearch

logging.basicConfig(
    level=logging.DEBUG, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)
logging.getLogger("pyrogram").setLevel(logging.WARNING)


@Client.on_message(filters.regex(pattern=r"^(Search)"))

async def ytsearch(_, message: Message):
    
    keyboard = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton(
                    "🗑 بستن", callback_data="close",
                )
            ]
        ]
    )
    
    try:
        query = ""
        english = 'search'
        pm = message.text.lower()
        if english in pm:
            query += str(message.text[6:])
        if len(query) < 1:
            await message.reply_text("search **به یک متن نیاز دارد**")
            return
        m = await message.reply_text("🔎 **جستجو...**")
        results = YoutubeSearch(query, max_results=5).to_dict()
        i = 0
        text = ""
        while i < 5:
            text += f"🏷 **نام:** __{results[i]['title']}__\n"
            text += f"⏱ **زمان:** `{results[i]['duration']}`\n"
            text += f"👀 **بازدید:** `{results[i]['views']}`\n"
            text += f"📣 **کانال:** {results[i]['channel']}\n"
            text += f"🔗: https://www.youtube.com{results[i]['url_suffix']}\n\n"
            i += 1
        await m.edit(text, reply_markup=keyboard, disable_web_page_preview=True)
    except Exception as e:
        await m.edit(str(e))
