import os
from os import getenv
from dotenv import load_dotenv

if os.path.exists("local.env"):
    load_dotenv("local.env")

load_dotenv()
que = {}
admins = {}
SESSION_NAME = getenv("SESSION_NAME", "makhusicmusic")
BOT_TOKEN = getenv("BOT_TOKEN")
BOT_NAME = getenv("BOT_NAME", "Makhusic")
BG_IMAGE = getenv("BG_IMAGE", "https://telegra.ph/file/76247e33e337030a0a4cb.png")
THUMB_IMG = getenv("THUMB_IMG", "https://telegra.ph/file/c9a96f98c36c5dbe8bc7b.png")
AUD_IMG = getenv("AUD_IMG", "https://telegra.ph/file/6a82f9f86eadb071f7886.png")
QUE_IMG = getenv("QUE_IMG", "https://telegra.ph/file/3378780ea24250433f39c.png")
CMD_IMG = getenv("CMD_IMG", "https://telegra.ph/file/56e9ccbc45b78e77c0d51.png")
ALIVE_IMG = getenv("ALIVE_IMG", "https://telegra.ph/file/c83b000f004f01897fe18.png")
API_ID = int(getenv("API_ID"))
API_HASH = getenv("API_HASH")
BOT_USERNAME = getenv("BOT_USERNAME", "MakhusicBot")
ASSISTANT_NAME = getenv("ASSISTANT_NAME", "MakhusicPlayer")
GROUP_SUPPORT = getenv("GROUP_SUPPORT", "MakhusicSupport")
UPDATES_CHANNEL = getenv("UPDATES_CHANNEL", "DameShomaGarm")
OWNER_NAME = getenv("OWNER_NAME", "M4hbod")
ALIVE_NAME = getenv("ALIVE_NAME", "Mahbod")
OWNER_ID = int(os.environ.get("OWNER_ID"))
DURATION_LIMIT = int(getenv("DURATION_LIMIT", "60"))
COMMAND_PREFIXES = list(getenv("COMMAND_PREFIXES", "/ ! .").split())
SUDO_USERS = list(map(int, getenv("SUDO_USERS").split()))



